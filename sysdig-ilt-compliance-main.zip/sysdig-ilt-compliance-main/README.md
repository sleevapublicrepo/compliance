# sysdig-ilt-compliance
Training resources for CSPM and KSPM detection and remediation with Sysdig Secure

Part of the manifest are cloned from: https://github.com/bridgecrewio/terragoat
